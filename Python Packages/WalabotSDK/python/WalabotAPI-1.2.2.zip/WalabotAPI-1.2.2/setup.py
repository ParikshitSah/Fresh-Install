from distutils.core import setup

setup(
    name = 'WalabotAPI',
    version = '1.2.2',
    description = 'Access to Walabot API for RF 3D sensing and image processing',
    author='Vayyar',
    author_email='support@walabot.com',
    url='http://walabot.com/',
    classifiers=['Programming Language :: Python :: 2', 'Programming Language :: Python :: 3'],
    py_modules=['WalabotAPI']  
)
